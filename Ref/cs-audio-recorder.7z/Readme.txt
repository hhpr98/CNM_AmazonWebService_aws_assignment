
CSAudioRecorder.

The CSAudioRecorder is a .NET library that allows you to record sound from any source, 
easily, using C#, VB and any other .NET language that support the .NET Framework and 
.NET Core platforms.

Sources
You can record sound from the microphone or any other audio device using the WASAPI 
and the LineIn (low level). Also, you can record just 'what you hear' using the WASAPI 
Loopback.

Destination
The destination audio format can be AAC, APE, MP2, MP3, OGG, ACM WAV, PCM WAV and WMA 
with a spesific samples, bitrate and channels.

Easily
You can do all this and more, fast and easily, with a few lines of source code only.
 
Benefits
	 * .NET library for .NET Framework and .NET Core.
	 * For WPF / Winform / Console Apps.
	 * Record audio from any audio device.
	 * Also, record from Telephony / Voide Modem devices.
	 * Low level recorder (LineIn Recorder).
	 * High level recorder (WASAPI Recorder).
	 * Record what you hear (WASAPI Loopback).
	 * To 8+ types of audio formats:
		 * AAC - Advanced Audio Coding
		 * APE - Monkey's Audio
		 * MP2 - MPEG Audio Layer II
		 * MP3 - MPEG Audio Layer III
		 * OGG - Vorbis Compressed
		 * ACM WAV - Audio Compression Manager
		 * PCM WAV - Waveform Audio Format
		 * WMA - Windows Media Audio
	 * Set the recording format:
		 * 48Khz to 8Khz sample rates.
		 * 8, 16, 24 and 32 bits depth.
		 * Mono or stereo.
	 * Unlimited recording time and length.
	 * Silence detection.
	 * Start to record when noise is detected.
	 * Stop to record when silence is detected.
	 * Record / Pause Record / Stop Record.
	 * Get all installed audio devices.
	 * Get the default audio device.
	 * Get the recorded length on real time.
	 * Get the recorded file size on real time.
	 * Embedly audio visualization:
		 * Set the color base.
		 * Set the color max.
		 * Set the interval.
		 * Set the number of bars to display.
		 * Set the spacing between the bars.
		 * Embedly audio meter.
	 * Built in ID3 editor:
		 * Set any ID3 tag of the destination file.
		 * Set the title, album, track#, comment, artist etc.
		 * Set the ID3 image of the destination file.
	 * Many relevant events.
	 * Built in threads handling.
	 * Safe exit.
	 * Can be run as a library.
	 * Easy to use.
	 * For C# / VB / ASP .NET.
	 * C# / VB .NET well documented examples.
	 * Cut your developing time up to 80%.
	 * Just import the library to your program and start to work immediately.
	 * The source code of this component is also available.
	 * Can be use in a FREE and commercial products.

Instructions
-	Add reference to the CSAudioRecorder.dll.
-	Copy the 'Plugins' folder to the CSAudioRecorder.dll directory.


Examples
-	The are examples of using this library under the 'Examples' folder.
-	Open the .sln file with Visual Studio 2017 / 2019.


Distribution:
-	The CSAudioRecorder is available for FREE for learning or for FREE purposes, 
	for commercial or any other use please order a license:
	https://microncode.com/developers/cs-audio-recorder/?cmd=order

-	All the external libraries (Plugins) the CSAudioRecorder uses are licensed 
	under MSPL / LGPL. You can distribute them with your commerical 
	projects, just add the credits.txt file to the dlls / documentation
	directory of your project.
	